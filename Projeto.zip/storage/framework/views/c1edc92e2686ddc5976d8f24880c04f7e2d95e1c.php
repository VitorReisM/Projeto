
<link href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('css/bootstrap-grid.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('css/bootstrap-reboot.min.css')); ?>" rel="stylesheet">


<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

<link href="<?php echo e(URL::asset('css/style.css')); ?>" rel="stylesheet">



<script
        src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha256-k2WSCIexGzOj3Euiig+TlR8gA0EmPjuc79OEeY5L45g="
        crossorigin="anonymous"></script>


<script src="<?php echo e(URL::asset('js/isotope.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/imagesloaded.pkgd.min.js')); ?>"></script>


<script src="<?php echo e(URL::asset('js/tinymce.min.js')); ?>"></script>