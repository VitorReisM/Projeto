

<script src="<?php echo e(URL::asset('js/popper.js')); ?>"></script>


<script src="<?php echo e(URL::asset('js/bootstrap.min.js')); ?>"></script>
