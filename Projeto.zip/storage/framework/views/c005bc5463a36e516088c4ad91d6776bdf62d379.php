<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Fast and Heavy</title>

        <?php echo $__env->make("layout.header", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body>
        
    </body>
    <footer>
        <?php echo $__env->make("layout.footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </footer>
</html>
