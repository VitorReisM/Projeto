
{{-- Requirement for BootStrap--}}
<script src="{{ URL::asset('js/popper.js') }}"></script>

{{-- BootStrap --}}
<script src="{{ URL::asset('js/bootstrap.min.js') }}"></script>
