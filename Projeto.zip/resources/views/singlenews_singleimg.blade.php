@extends('layouts.main')

@section('title', 'Home')

@section('content')
    <div class="row justify-content-md-center">
        <div class="col-md-auto">
            <img src="http://via.placeholder.com/500x350" alt="" style="">
        </div>
    </div>

    Lorem ipsum dolor sit amet, at cetero epicuri dissentiet per, eum cu suas neglegentur instructior. Ea prima fiere
    nt qui, modus dolorem in sed, odi<br>o paulo usu an. Postea lobortis in mel, an per mucius gubergren, iriure vidisse
    evertitur ea vis. Qui causae<br>
    sadipscing eu, semper conclusionemque te per. Id nemore dissentiunt nec, dictas comprehensam nam in.

    His ut omittam assueverit vituperatoribus. Et vix animal sensibus. Vim no esse impedit, veri ornatus petentium qui
    no. Est in sonet denique adolesc<br>ens, pri malis audiam et. Ei illud decore sea. Nonumy nominati euripidis ne ius, qu
    i quando fabellas referrentur ei, eum laudem<br> repudiandae ex.<br>

    At est libris feugiat accommodare, et solum graeci appareat nam. Ei mei quis vidit maiestatis. Suas alterum conclus
    ionemque vel eu, te percipitur omittantur me<br>diocritatem sed. Rebum volumus aliquando no vis. Debitis accusam ea eam
    . Dicta facete et mei.<br>

    Usu ei falli salutatus appellantur. No pri falli vocent inimicus, per ut nostrud invenire. Delicata corrumpit mode
    ratius his ex. Pri qualisque<br> consetetur no, vim<br> ex tritani honestatis, solet lobortis mel ea. Mollis scripta repr
    ehendunt an vis, sed aliquip malorum volutpat ut.<br>

    Vis ex purto mucius, mel dictas repudiandae id, prompta moderatius neglegentur ei sea. Cu duo paulo sadipscing. Vi
    x nostro pericula et<br>. At tation putant nam, at mei erat adhuc utroque, illum ignota et vis. Vis case appellantur
    ne. In nibh ullum necessitatibus eam, enim periculis cum no, idque utamur argumentum in mei.

@stop
